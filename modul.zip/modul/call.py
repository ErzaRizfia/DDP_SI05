import bangundatar as hitung


print("## Perhitungan Luas & Keliling Persegi")

hitung.l_persegi(4)
hitung.l_persegi(6)

print()
print ("## Perhitungan Luas & Keliling Persegi Panjang")

hitung.l_persegi_panjang(7,9)

print()
print("## Perhitungan luas Segitiga")

hitung.l_segita(9,6)

print()
print("## Perhitungan luas Lingkaran")

hitung.l_lingkaran(6,8)

print()
print("## Perhitungan luas Jajar genjang")

hitung.l_jajar_genjang(8,5)

print()
print("## Perhitungan luas kubus")

hitung.l_kubus (8)

print()
print("## Perhitungan luas balok")

hitung.l_balok (10,8,5)

print()
print("## Perhitungan luas tabung")

hitung.l_tabung (10,5)

print()
print("## Perhitungan luas kerucut")

hitung.l_kerucut (10,5)

print()
print("## Perhitungan luas bola")

hitung.l_bola (10)